package com.example.Ecommerce.Apllication.Controller;

import com.example.Ecommerce.Apllication.Model.User;
import com.example.Ecommerce.Apllication.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {
     @Autowired
     UserService userservice;
     @PostMapping("/signup")
     @ResponseStatus(HttpStatus.OK)
     public void signup(@RequestBody  User u){
          System.out.println("asf");
         userservice.signup(u);
     }
     @PostMapping("/login")
     public String userlogin(@RequestBody User u){
           String useremail=u.getUseremail();
           String password=u.getPassword();
         System.out.println("login");;
           return userservice.userlogin(useremail,password);
     }
     @GetMapping("/allusers")
    public List<User> getallusers(){
         return userservice.getallusers();
     }
}
