package com.example.Ecommerce.Apllication.Service;

import com.example.Ecommerce.Apllication.Model.User;
import com.example.Ecommerce.Apllication.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private UserRepository userrepo;
    private TokenService tokenService;
    @Autowired
    public UserService(UserRepository userrepo,TokenService tokenService){
        this.userrepo=userrepo;
        this.tokenService=tokenService;
    }

    public void signup(User u) {
        userrepo.save(u);
    }

    public String userlogin(String useremail, String password) {
        boolean userexist = existbyemail(useremail);

        if (userexist) {
            User u = userrepo.getuserbyemail(useremail);
            System.out.println(u.getPassword());
            String pword = u.getPassword();
            if (pword.equals(password)) {
                return "{" +
                        "\"message\":" + "Successfully logged user\",\n" +
                        "\"data\":" + u + ",\n" +
                        "\"Email: " + u.getUseremail() + ", \n" +
                        "\"token:" + tokenService.createTokenFunction(u.getUserid()) + "\" " +
                        "}";
            }
        }
        return "{" +
                "\"message\":"+"Authonitacation failed\",\n"+
                "\"data\":"+",\n"+
                "}";
    }


    public boolean existbyemail(String usermail) {

        Optional<User> u = Optional.ofNullable(userrepo.getuserbyemail(usermail));
        System.out.println(u.get().getUseremail());
        if (u.isEmpty()) return false;
        return true;
    }
    public List<User> getallusers(){
        return userrepo.findAll();
    }
}
