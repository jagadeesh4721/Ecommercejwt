package com.example.Ecommerce.Apllication.Service;

import com.example.Ecommerce.Apllication.Model.Category;
import com.example.Ecommerce.Apllication.Model.Product;
import com.example.Ecommerce.Apllication.Repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoryService {
     @Autowired
    CategoryRepository categoryrepo;
     public void addcategory(Category c){
         categoryrepo.save(c);
     }
     public Optional<Category> updateid(int id, Category c){
          Optional<Category> category= categoryrepo.findById(id);
          if(category.isEmpty()) return null;
          if(c.getCategory_name()!=null)
          category.get().setCategory_name(c.getCategory_name());
          if(c.getCategory_descrption()!=null)
          category.get().setCategory_descrption(c.getCategory_descrption());
          categoryrepo.save(category.get());
          return category;
     }
     public String deleteid(int id){
         Optional<Category> category=categoryrepo.findById(id);
         if(category.isEmpty()){
             return "id is already deleted";
         }
         categoryrepo.deleteById(id);
         return "id deleted";
     }
    public List<Category> getallcategories(){
        return categoryrepo.findAll();
    }
    public void linkProductWithCategory(int id,List<Product>products){
         Optional<Category>o=categoryrepo.findById(id);
         if(o.isEmpty()) return ;
         Category existingcategory=o.get();
         List<Product> existproducts=existingcategory.getProductlist();
        existproducts.addAll(products);
       o.get().setProductlist(existproducts);
    }
}
